package routers //用户层 接收用户URL

import (
	"GOCODE/function"

	"github.com/gin-gonic/gin" //用于处理 HTTP 请求和响应。
)

func URouter() *gin.Engine {
	r := gin.Default() //创建一个gin的实例用于处理 HTTP 请求和响应

	uGroup := r.Group("/product") //但凡接收到这个前缀进入此方法体
	{

		//添加商品
		uGroup.POST("/product/addProduct", function.AddProduct) //POST头 请求通常用于创建或更新资源

		//ID查询
		uGroup.GET("/product/GetIdQuery", function.IDquery) //GET头 请求通常用于检索资源

		//根据id删除商品
		uGroup.POST("/product/delProduct", function.IdDeleteProduct)

		//根据id更新商品
		uGroup.POST("/product/IdUpdateProduct", function.IdUpdateProduct)
		// 查询所有个人上架商品
		uGroup.GET("/product/GetProductAll", function.GetProductAll)
		//分类查询

		//关键词查询

		//分页查询商品
	}

	return r
}
