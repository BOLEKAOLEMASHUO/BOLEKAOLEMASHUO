package main

import (
	routers "GOCODE/Routers"
	"GOCODE/sql"
	//	"GOCODE/Lattice"
	//"net/http" 
)

func main() {
	err := sql.InitMysql() //连接数据库
	if err != nil {
		panic(err)
	}
	// router := gin.Default()                //创建一个gin路由器的实例
	// router.GET("/", func(c *gin.Context) { //对这个路由器定义一个GET请求 当用户访问 ***/ 时，路由系统将匹配根路径，并调用指定的处理函数
	// 	c.String(http.StatusOK, "Hello, Gin!")
	// })
	r := routers.URouter() //启动路由

	r.Run(":8080")
}
