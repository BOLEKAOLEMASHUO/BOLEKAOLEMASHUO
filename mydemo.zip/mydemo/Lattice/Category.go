package Lattice

// 数据库结构体分类表
type Category struct {
	Category_id          int    `json:"Category_id"`          //分类ID
	Category_name        string `json:"Category_name"`        //分类名称
	Category_description string `json:"Category_description"` //分类描述

}
