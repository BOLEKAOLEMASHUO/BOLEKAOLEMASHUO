package Lattice

// 数据库结构体商品ID、商品分类、商品名称、商品描述、商品价格、商品图片
type Product struct {
	Product_id          int     `json:"Product_id"`          //商品ID 【主键】
	Product_category    string  `json:"Product_category"`    //商品分类 【外键】
	Product_name        string  `json:"Product_name"`        //商品名称
	Product_stock       int     `json:"Product_stock"`       //商品库存
	Product_description string  `json:"Product_description"` //商品描述
	Product_price       float64 `json:"Product_price"`       //商品价格
	Product_img         string  `json:"Product_img"`         //商品图片
	Product_status      string  `json:"Product_status"`      //商品状态
	Created_at          string  `json:"Created_at"`          //创建时间
	Updated_at          string  `json:"Updated_at"`          //更新时间
}
