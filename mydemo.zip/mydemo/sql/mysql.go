package sql

import (
	"fmt"
	"os"

	_ "github.com/go-sql-driver/mysql" //导入数据库
	"github.com/jinzhu/gorm"
	"gopkg.in/yaml.v2" //数据库配置文件
)

const DRIVER = "mysql" //定义一个常量 mysql驱动的名字

var DB *gorm.DB //数据库指针 用来连接数据库 操作数据库

type conf_sp struct { //需要返回给前端的东西
	Url      string `yaml:"url"`
	UserName string `yaml:"userName"`
	PassWord string `yaml:"passWord"`
	DbName   string `yaml:"dbName"`
	Port     string `yaml:"post"`
}

// 程序启动时 获取配置参数数据传入到结构体 用户不能直接操作
func (cs *conf_sp) getConf() conf_sp {
	//读取配置文件  ，更改数据库信息 只需访问yaml文件
	yamlFile, err := os.ReadFile("sjkSet/mysql.yaml") //从yaml文件读取数据 返回一个切片存入读取的数据
	if err != nil {
		fmt.Println(err)
	}
	err = yaml.Unmarshal(yamlFile, cs) //将读取到的字符串转成结构体
	if err != nil {
		fmt.Println(err)
	}
	return *cs //返回带有数据的结构体
}

func InitMysql() (err error) { //连接mysql

	var cs conf_sp
	conf_sp := cs.getConf() //通过getConf方法图区配置文件信息赋值给conf_sp变量
	//将yaml配置参数拼接成连接数据库的url

	conn_url := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local", //每一个%s是一个占位符 对应下面五个参数
		conf_sp.UserName,
		conf_sp.PassWord,
		conf_sp.Url,
		conf_sp.Port,
		conf_sp.DbName,
	)
	fmt.Println(conn_url)
	//连接数据库
	DB, err := gorm.Open(DRIVER, conn_url) //传入一个数据库名字常量，和连接数据库的url

	if err != nil {
		fmt.Println("链接失败,", err.Error())
		return
	}

	return DB.DB().Ping() //返回连接的是否成功

}

func Close() {
	DB.Close() //关闭数据库
}
