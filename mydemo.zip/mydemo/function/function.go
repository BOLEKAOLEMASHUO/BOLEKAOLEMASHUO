package function //将用户输入传递给服务层  传参层

import (
	"GOCODE/Lattice" //结构体导入

	//http连接包
	"net/http"
	//gin框架的依赖
	"github.com/gin-gonic/gin" //用于处理 HTTP 请求和响应。
	//service 层方法
	"GOCODE/Service"
)

// 添加商品 头字母大写 被用户层调用
func AddProduct(u *gin.Context) { //传入一个请求信息 如请求方法（如GET、POST等）、请求头、请求路径、请求参数等

	var sp Lattice.Product         //定义一个实体类型商品的变量 接收用户数据
	u.ShouldBind(&sp)              //将发来请求中的数据绑定到sp中  失败返回err
	err := Service.AddProduct(&sp) //调用服务层面的方法 执行操作
	if u != nil {                  //添加失败
		u.JSON(http.StatusBadGateway, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  0,           //返回一个状态码0
			"message": "添加失败",      //输出添加失败
			"err":     err.Error(), //输出错误信息
		})
		return
	} else { //添加成功
		u.JSON(http.StatusOK, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  200,    //返回一个状态码200
			"message": "添加成功", //输出添加成功

		})
		return
	}
}

// ID查询
func IDquery(u *gin.Context) { //接受用户发来的查询请求
	var sp Lattice.Product //定义实体类型商品变量 接收数据
	u.ShouldBind(&sp)      //将发来的请求保定到sp中
	//Service.IdQuery()

}

// 根据id删除商品
func IdDeleteProduct(u *gin.Context) {
	var sp Lattice.Product       //定义一个实体类型商品的变量 接收用户数据
	u.ShouldBind(&sp.Product_id) //将发来请求中的数据绑定到sp中  失败返回err
	err := Service.IdDelete(&sp) //调用服务层面的方法 执行操作
	if u != nil {                //删除失败
		u.JSON(http.StatusBadGateway, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  0,           //返回一个状态码0
			"message": "删除失败",      //输出删除失败
			"err":     err.Error(), //输出错误信息
		})
		return
	} else { //添加成功
		u.JSON(http.StatusOK, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  200,    //返回一个状态码200
			"message": "删除成功", //输出删除成功

		})
		return
	}
}

// 根据id更新商品
func IdUpdateProduct(u *gin.Context) {
	var sp Lattice.Product       //定义一个实体类型商品的变量 接收用户数据
	u.ShouldBind(&sp.Product_id) //将发来请求中的数据绑定到sp中  失败返回err
	err := Service.IdUpdate(&sp) //调用服务层面的方法 执行操作
	if u != nil {                //更新失败
		u.JSON(http.StatusBadGateway, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  0,           //返回一个状态码0
			"message": "更新失败",      //输出更新失败
			"err":     err.Error(), //输出错误信息
		})
		return
	} else { //添加成功
		u.JSON(http.StatusOK, gin.H{ //第一个参数是一个状态码，第二个参数是一个键值对
			"status":  200,    //返回一个状态码200
			"message": "更新成功", //输出更新成功

		})
		return
	}
}

// 查询所有个人上架商品
func GetProductAll(u *gin.Context) {

}

//分类查询

//关键词查询

//分页查询商品
