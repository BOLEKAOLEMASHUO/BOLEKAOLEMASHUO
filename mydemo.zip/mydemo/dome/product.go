package main

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

// 数据库结构体商品ID、商品分类、商品名称、商品描述、商品价格、商品图片
type Product struct {
	product_id          int     //商品ID 【主键】
	product_category    string  //商品分类 【外键】
	product_name        string  //商品名称
	product_description string  //商品描述
	product_price       float64 //商品价格
	product_img         string  //商品图片
}

var db *sql.DB //数据库指针 用来连接数据库 操作数据库

func init() { //连接mysql连接语句放在 init方法里 此方法优先main
	database, err := sql.Open("mysql", "root:root@tcp(127.0.0.1:3306)/mytest")
	if err != nil {
		fmt.Println("失败,", err.Error())
		return
	} else {
		fmt.Println("打开数据库成功")
	}
	db = database //指针指向这个数s据库

	//关闭数据库连接
	//defer db.Close()

	if err != nil {
		fmt.Printf("数据库连接失败: %v\n", err.Error())
	} else {
		fmt.Println("数据库连接成功")
	}

}

// 添加商品
// 方法添加限制 管理员可以对其操作
func addProduct(p Product) {

	//添加数据
	/* fmt.Println("请输入商品分类")   //***此处传入分类表 接入外键***
	fmt.Scan(&p.product_category) */
	fmt.Println("请输入商品名称")
	fmt.Scan(&p.product_name)
	fmt.Println("请输入商品描述")
	fmt.Scan(&p.product_description)
	fmt.Println("请输入商品价格")
	fmt.Scan(&p.product_price)

	//****************************************************
	//此处对用户输入边缘限制
	//****************************************************

	/* fmt.Println("请输入商品图片")  //***图片暂预留***
	fmt.Scan(&p.product_img) */

	//根据商品名称判断是否上架重复商品
	db.QueryRow("SELECT product_name FROM product WHERE product_name = ?", p.product_name)
	fmt.Printf("p.product_id: %v\n", p.product_id)
	if p.product_id == 0 { //没有重复

		//插入数据  名称、描述、价格、
		sqlStr := "insert into Product(product_name,product_description,product_price) values(?,?,?)"
		stmt, err := db.Prepare(sqlStr)
		defer stmt.Close()                                                            //添加操作结束后 关闭数据库
		res, err := stmt.Exec(p.product_name, p.product_description, p.product_price) //
		if err != nil {                                                               //添加失败
			fmt.Println("数据库添加失败:", err.Error())
			return
		} else {
			fmt.Println("添加成功")
		}
		arref, _ := res.RowsAffected()
		fmt.Println("受影响的行数%v", arref)
	} else {
		fmt.Println("商品名称重复")
		//此处可以递归重新输入进行判断
	}
}

// 【管理员】删除商品
func deleteProduct(id int) { //需要传入商品自增id
	//根据id删除数据
	stmt, err := db.Exec("delete from Product where product_id=?", id)
	if err != nil { //删除失败
		fmt.Println("数据库删除失败:", err.Error())
		return
	} else {
		fmt.Println("删除成功")
	}

	arref, _ := stmt.RowsAffected()
	fmt.Println("受影响的行数%v", arref)

}

// 查询所有个人上架商品
func queryAllProduct(p1 Product) {
	rows, err := db.Query("SELECT * FROM Product") //查询所有商品语句
	if err != nil {
		fmt.Println("数据库查询失败:", err.Error())
		return
	}
	defer rows.Close() //最后关闭数据库链接

	productList := make([]Product, 0)
	for rows.Next() { //如果有下一条一直循环执行
		err = rows.Scan(&p1.product_name, p1.product_description, &p1.product_price) //查询到的每条商品的 名字、描述、价格
		if err != nil {
			fmt.Println("数据绑定失败:", err.Error())
			return
		}
		productList = append(productList, p1) //当前数据传入切片
	}
	fmt.Println(productList) //输出切片

}

// 关键词查询
func queryProduct(p1 Product) {
	rows, err := db.Query("SELECT * FROM Product where product_name=?", p1.product_name)
	if err != nil {
		fmt.Println("数据库查询失败:", err.Error())
		return
	}
	defer rows.Close() //最后关闭数据库链接

	productList := make([]Product, 0)
	for rows.Next() { //如果有下一条一直循环执行
		err = rows.Scan(&p1.product_name, p1.product_description, &p1.product_price) //查询到的每条商品的 名字、描述、价格
		if err != nil {
			fmt.Println("数据绑定失败:", err.Error())
			return
		}
		productList = append(productList, p1) //当前数据传入切片
	}
	fmt.Println(productList) //输出切片

}

/* //模糊查询
func queryProduct2(p1 Product)


*/
/*
// 修改语句
func xiugai(u1 User) {



}
*/
func main() {

	var p1 Product

	//添加一条数据
	addProduct(p1)

}
