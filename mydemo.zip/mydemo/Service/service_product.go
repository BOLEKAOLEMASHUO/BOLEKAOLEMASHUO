package Service //服务层方法 实现

import (
	//需要用到的结构体
	"GOCODE/Lattice"
	"GOCODE/sql"
)

// 新增商品信息  方法名大写开头 被传参层调用
func AddProduct(p *Lattice.Product) (err error) {
	err = sql.DB.Create(p).Error //调用数据库操作 添加数据
	if err != nil {
		return err
	}
	return
}

// 根据id删除商品
func IdDelete(id *Lattice.Product) (err error) {

	//where 条件语句 后面跟上id 表示 根据id做【删除】 delete(删除表中 条件匹配的 product_id )
	err = sql.DB.Where("Product_id=?", id).Delete(&Lattice.Product{}).Error
	return

}

// 根据id更新商品
func IdUpdate(id *Lattice.Product) (err error) {

	//where 条件语句 后面跟上id 表示 根据id做【更新】 Update(更新表中 条件匹配的 product_id )
	err = sql.DB.Where("Product_id=?", id).Update(&Lattice.Product{}).Error
	return

}

//ID查询

func IdQuery(id *Lattice.Product) (err error) {
	//where 条件语句 后面跟上id 表示 根据id做【查询】 Select(查询表中 条件匹配的 product_id )
	err = sql.DB.Where("Product_id=?", id).Select(&Lattice.Product{}).Error
	return

}

// 查询所有个人上架商品
func QueryAll() (err error) {
	//Select(查询表中 所有{} )
	err = sql.DB.Select(&Lattice.Product{}).Error
	return

}

//分类查询

//关键词查询

//分页查询商品
